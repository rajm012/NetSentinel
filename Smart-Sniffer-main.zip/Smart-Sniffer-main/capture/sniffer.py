import scapy.all as scapy
from scapy.layers.http import HTTPRequest
from scapy.layers.dns import DNSQR
from scapy.layers.inet import IP, TCP, UDP, ICMP
from scapy.layers.l2 import ARP
from scapy.layers.dot11 import Dot11Deauth
import json
import time
import threading
from datetime import datetime
from scapy.packet import Raw

LOG_FILE = 'sniffer_log.json'
seen_ports = {}
syn_counts = {}
dns_query_counts = {}
arp_spoof_cache = {}

THREATS = {
    "SYN_FLOOD": "SYN Flood / Port Scan",
    "ARP_SPOOF": "ARP Spoofing",
    "DNS_TUNNEL": "DNS Tunneling",
    "ICMP_FLOOD": "ICMP Flood",
    "UDP_FLOOD": "UDP Flood",
    "HTTP_XSS": "XSS Injection",
    "HTTP_SQLI": "SQL Injection",
    "ROGUE_AP": "Deauthentication Attack",
    "TLS_ANOMALY": "TLS Fingerprinting Anomaly"
}

def log_packet(pkt_dict):
    with open(LOG_FILE, 'a') as f:
        f.write(json.dumps(pkt_dict) + "\n")

def detect_syn_flood(pkt):
    if pkt.haslayer(TCP) and pkt[TCP].flags == 'S':
        ip = pkt[IP].src
        syn_counts[ip] = syn_counts.get(ip, 0) + 1
        if syn_counts[ip] > 100:
            return THREATS["SYN_FLOOD"]
    return None

def detect_arp_spoof(pkt):
    if pkt.haslayer(ARP) and pkt[ARP].op == 2:  # is-at response
        src_ip = pkt[ARP].psrc
        src_mac = pkt[ARP].hwsrc
        if src_ip in arp_spoof_cache and arp_spoof_cache[src_ip] != src_mac:
            return THREATS["ARP_SPOOF"]
        arp_spoof_cache[src_ip] = src_mac
    return None

def detect_dns_tunnel(pkt):
    if pkt.haslayer(DNSQR):
        domain = pkt[DNSQR].qname.decode(errors='ignore')
        dns_query_counts[domain] = dns_query_counts.get(domain, 0) + 1
        if len(domain.split('.')) > 5 and len(domain) > 50:
            return THREATS["DNS_TUNNEL"]
    return None

def detect_icmp_udp_flood(pkt):
    if pkt.haslayer(ICMP) or pkt.haslayer(UDP):
        ip = pkt[IP].src
        key = f"{ip}_icmp_udp"
        syn_counts[key] = syn_counts.get(key, 0) + 1
        if syn_counts[key] > 100:
            return THREATS["ICMP_FLOOD"] if pkt.haslayer(ICMP) else THREATS["UDP_FLOOD"]
    return None

def detect_http_threats(pkt):
    if pkt.haslayer(HTTPRequest):
        http_payload = str(pkt[HTTPRequest].Path)
        if "<script>" in http_payload or "onerror=" in http_payload:
            return THREATS["HTTP_XSS"]
        if "UNION SELECT" in http_payload.upper() or "DROP TABLE" in http_payload.upper():
            return THREATS["HTTP_SQLI"]
    return None

def detect_rogue_ap(pkt):
    if pkt.haslayer(Dot11Deauth):
        return THREATS["ROGUE_AP"]
    return None

def detect_tls(pkt):
    if pkt.haslayer(TCP) and pkt[TCP].dport == 443:
        if pkt.haslayer(Raw) and len(pkt[Raw].load) < 20:
            return THREATS["TLS_ANOMALY"]
    return None

def classify_threat(pkt):
    detectors = [
        detect_syn_flood,
        detect_arp_spoof,
        detect_dns_tunnel,
        detect_icmp_udp_flood,
        detect_http_threats,
        detect_rogue_ap,
        detect_tls
    ]
    for detector in detectors:
        threat = detector(pkt)
        if threat:
            return threat
    return "normal"

def packet_to_dict(pkt, threat_type):
    return {
        "timestamp": datetime.now().isoformat(),
        "src_ip": pkt[IP].src if pkt.haslayer(IP) else None,
        "dst_ip": pkt[IP].dst if pkt.haslayer(IP) else None,
        "protocol": pkt.lastlayer().name,
        "summary": pkt.summary(),
        "threat_type": threat_type
    }

def sniff_packets(timeout=30):
    print(f"[*] Starting packet sniffing for {timeout} seconds...")
    captured_packets = []

    def process(pkt):
        try:
            threat_type = classify_threat(pkt)
            pkt_dict = packet_to_dict(pkt, threat_type)
            log_packet(pkt_dict)
            if threat_type != "normal":
                print(f"[!] Threat Detected: {threat_type} => {pkt.summary()}")
        except Exception as e:
            print(f"[x] Error processing packet: {e}")

    scapy.sniff(prn=process, timeout=timeout, store=False)

def main():
    while True:
        sniff_packets(timeout=30)
        user_input = input("\nDo you want to continue sniffing? (y/n): ").strip().lower()
        if user_input != 'y':
            print("[*] Sniffing stopped.")
            break

if __name__ == "__main__":
    print("[*] Network Threat Sniffer CLI - Running...")
    main()


# Wi-Fi, eth0, Ethernet, wlan0, eth1
