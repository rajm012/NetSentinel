import subprocess
from parser.protocol_parser import run_detection
from ml_model.anomaly_detector import train_and_predict

def run_all():
    print("[*] Running Protocol Analysis...")
    alerts = run_detection()

    print("[*] Running ML-based Anomaly Detection...")
    train_and_predict()

if __name__ == "__main__":
    run_all()


# sniffer/Scripts/activate
