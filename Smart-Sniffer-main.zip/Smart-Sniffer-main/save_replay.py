# save_replay.py
import json
import time
import argparse

def replay_logs(log_file, delay=1):
    with open(log_file, "r") as f:
        for line in f:
            try:
                packet = json.loads(line.strip())
                print(json.dumps(packet, indent=2))
                time.sleep(delay)
            except json.JSONDecodeError:
                continue

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Replay captured traffic logs.")
    parser.add_argument("-f", "--file", default="E:\\4th Semester\\Smart Sniffer\\ml_model\\anomaly_logs.json", help="Path to log file")
    parser.add_argument("-d", "--delay", type=float, default=1.0, help="Delay between packets (in seconds)")
    args = parser.parse_args()

    print(f"🔁 Replaying packets from {args.file} with {args.delay}s delay...")
    replay_logs(args.file, args.delay)


# --------------------------------

# {
#   "timestamp": "2025-04-08T21:04:33.982077",
#   "src_mac": "b8:1e:a4:8e:d3:80",
#   "dst_mac": "00:1c:73:00:00:91",
#   "protocol": "UDP",
#   "details": {
#     "sport": 56925,
#     "dport": 53
#   },
#   "threats": [],
#   "src_ip": "172.18.32.234",
#   "dst_ip": "10.7.0.1"
# }
# {
#   "timestamp": "2025-04-08T21:04:33.997888",
#   "src_mac": "30:86:2d:60:81:30",
#   "dst_mac": "b8:1e:a4:8e:d3:80",
#   "protocol": "UDP",
#   "details": {
#     "sport": 53,
#     "dport": 56925
#   },
#   "threats": [],
#   "src_ip": "10.7.0.1",
#   "dst_ip": "172.18.32.234"
# }
# {
#   "timestamp": "2025-04-08T21:04:34.018195",
#   "src_mac": "30:86:2d:60:81:30",
#   "dst_mac": "b8:1e:a4:8e:d3:80",
#   "protocol": "UDP",
#   "details": {
#     "sport": 53,
#     "dport": 64095
#   },
#   "threats": [],
#   "src_ip": "10.7.0.1",
#   "dst_ip": "172.18.32.234"
# }
# {
#   "timestamp": "2025-04-08T21:04:34.170644",
#   "src_mac": "b8:1e:a4:8e:d3:80",
#   "dst_mac": "00:1c:73:00:00:91",
#   "protocol": "UDP",
#   "details": {
#     "sport": 58755,
#     "dport": 53
#   },
#   "threats": [],
#   "src_ip": "172.18.32.234",
#   "dst_ip": "10.7.0.1"
# }


# --------------------------------
