import json
from datetime import datetime

ALERT_LOG_FILE = "alerts.json"
ANOMALY_FILE = "E:\\4th Semester\\Smart Sniffer\\ml_model\\anomaly_logs_fixed.json"  # Output from ml_anomaly_detector.py

def load_anomalies(file_path):
    with open(file_path, "r") as f:
        return json.load(f)

def log_alert(alert_data):
    with open(ALERT_LOG_FILE, "a") as f:
        f.write(json.dumps(alert_data) + "\n")

def send_terminal_alert(alert):
    print("\n🚨 ALERT DETECTED 🚨")
    print(f"🔹 Time     : {alert.get('timestamp', 'N/A')}")
    print(f"🔹 Type     : {alert.get('type', 'Unknown')}")
    print(f"🔹 Severity : {alert.get('severity', 'Medium')}")
    print(f"🔹 Summary  : {alert.get('summary', 'No details')}")
    print(f"🔹 Source IP: {alert.get('src_ip', 'N/A')}")
    print(f"🔹 Target IP: {alert.get('dst_ip', 'N/A')}")


def trigger_alerts(anomalies):
    print("\n📢 Scanning anomalies for alert triggers...\n")
    for alert in anomalies:
        send_terminal_alert(alert)
        log_alert(alert)

if __name__ == "__main__":
    anomalies = load_anomalies(ANOMALY_FILE)
    if anomalies:
        trigger_alerts(anomalies)
    else:
        print("✅ No anomalies found. Network seems clean.")


# --------------------------------------------
# 🚨 ALERT DETECTED 🚨
# 🔹 Time     : 2025-04-08T21:05:39.740996
# 🔹 Type     : Unknown
# 🔹 Severity : Medium
# 🔹 Summary  : No details
# 🔹 Source IP: 172.18.32.234
# 🔹 Target IP: 20.42.73.27
# 🚨 ALERT DETECTED 🚨
# 🔹 Time     : 2025-04-08T21:05:39.742051
# 🔹 Type     : Unknown
# 🔹 Severity : Medium
# 🔹 Summary  : No details
# 🔹 Source IP: 172.18.32.234
# 🔹 Target IP: 20.42.73.27
# 🚨 ALERT DETECTED 🚨
# 🔹 Time     : 2025-04-08T21:05:39.743468
# 🔹 Type     : Unknown
# 🔹 Severity : Medium
# 🔹 Summary  : No details
# 🔹 Source IP: 172.18.32.234
# 🔹 Target IP: 20.42.73.27
# 🚨 ALERT DETECTED 🚨
# 🔹 Time     : 2025-04-08T21:05:39.752276
# 🔹 Type     : Unknown
# 🔹 Severity : Medium
# 🔹 Summary  : No details
# 🔹 Source IP: 20.42.73.27
# 🔹 Target IP: 172.18.32.234
# 🚨 ALERT DETECTED 🚨
# 🔹 Time     : 2025-04-08T21:05:39.754041
# 🔹 Type     : Unknown
# 🔹 Severity : Medium
# 🔹 Summary  : No details
# 🔹 Source IP: 20.42.73.27
# 🔹 Target IP: 172.18.32.234
# -----------------------------------------------