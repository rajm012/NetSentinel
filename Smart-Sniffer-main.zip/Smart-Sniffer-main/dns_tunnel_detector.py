# dns_tunnel_detector.py
import json
import os
from collections import defaultdict
from utils.entropy import calculate_entropy

LOG_FILE = "E:\\4th Semester\\Smart Sniffer\\ml_model\\anomaly_logs.json"

def is_suspicious_dns_query(query):
    if len(query) > 50 or calculate_entropy(query) > 4.5:
        return True
    return False

def detect_dns_tunnels():
    print("🔍 Scanning for DNS Tunneling...")
    if not os.path.exists(LOG_FILE):
        print("❌ Log file not found.")
        return

    with open(LOG_FILE, "r") as f:
        logs = [json.loads(line) for line in f]

    suspicious = []
    for entry in logs:
        if entry.get("protocol") == "DNS":
            query = str(entry["details"])
            if is_suspicious_dns_query(query):
                suspicious.append(entry)

    if suspicious:
        print(f"🚨 {len(suspicious)} Suspicious DNS Tunneling packets detected.")
        for s in suspicious:
            print(json.dumps(s, indent=2))
    else:
        print("✅ No DNS tunneling activity detected.")

if __name__ == "__main__":
    detect_dns_tunnels()


# -------------------------------------------------

# (sniffer) PS E:\4th Semester\Smart Sniffer> python dns_tunnel_detector.py
# 🔍 Scanning for DNS Tunneling...
# 🚨 3 Suspicious DNS Tunneling packets detected.
# {
#   "timestamp": "2025-04-08T21:05:01.778300",
#   "src_mac": "46:2b:b4:78:7b:d4",
#   "dst_mac": "33:33:00:00:00:fb",
#   "protocol": "DNS",
#   "details": "mDNS Ans [b'rpMac=0', b'rpHN=f4cb668b91ed', b'rpFl=0x20000', b'rpHA=4b683ddc8b6f', b'rpVr=640.1.1', b'rpAD=670aa6934afb', b'rpHI=2528a0692732', b'rpBA=EE:F5:AF:12:7F:01']",
#   "threats": []
# }
# {
#   "timestamp": "2025-04-08T21:05:02.806975",
#   "src_mac": "46:2b:b4:78:7b:d4",
#   "dst_mac": "33:33:00:00:00:fb",
#   "protocol": "DNS",
#   "details": "mDNS Ans [b'rpMac=0', b'rpHN=f4cb668b91ed', b'rpFl=0x20000', b'rpHA=4b683ddc8b6f', b'rpVr=640.1.1', b'rpAD=670aa6934afb', b'rpHI=2528a0692732', b'rpBA=EE:F5:AF:12:7F:01']",
#   "threats": []
# }
# {
#   "timestamp": "2025-04-08T21:05:26.243069",
#   "src_mac": "e8:65:38:22:33:75",
#   "dst_mac": "33:33:00:00:00:fb",
#   "protocol": "DNS",
#   "details": "mDNS Ans b'DESKTOP-UUMQ592._dosvc._tcp.local.'",
#   "threats": []
# }

# -------------------------------------------------