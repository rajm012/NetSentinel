# rogue_ap_detector.py
import json
import os

LOG_FILE = "E:\\4th Semester\\Smart Sniffer\\ml_model\\anomaly_logs.json"
TRUSTED_MACS = {"00:1A:2B:3C:4D:5E", "dc:45:46:dd:31:dc"}  # Add known AP MACs here

def detect_rogue_aps():
    print("📡 Scanning for Rogue Access Points...")

    if not os.path.exists(LOG_FILE):
        print("❌ Log file not found.")
        return

    seen_macs = set()
    with open(LOG_FILE, "r") as f:
        for line in f:
            packet = json.loads(line)
            src_mac = packet.get("src_mac")
            if src_mac and src_mac not in TRUSTED_MACS:
                seen_macs.add(src_mac)

    rogue = seen_macs - TRUSTED_MACS

    if rogue:
        print(f"🚨 Detected {len(rogue)} Rogue AP(s):")
        for mac in rogue:
            print(f"🔸 {mac}")
    else:
        print("✅ No Rogue Access Points found.")

if __name__ == "__main__":
    detect_rogue_aps()


# ----------------------------

# (sniffer) PS E:\4th Semester\Smart Sniffer> python rogue_ap_detector.py
# 📡 Scanning for Rogue Access Points...
# 🚨 Detected 19 Rogue AP(s):
# 🔸 b8:1e:a4:8e:d3:80
# 🔸 00:45:e2:d2:2f:01
# 🔸 94:21:57:ea:d7:11
# 🔸 4c:cc:6a:5e:7e:f8
# 🔸 a4:ae:11:19:89:27
# 🔸 46:2b:b4:78:7b:d4
# 🔸 00:24:1d:a5:64:d3
# 🔸 d0:39:57:eb:d5:75
# 🔸 e0:c2:64:58:68:bc
# 🔸 a6:01:21:b8:8c:d4
# 🔸 e8:fb:1c:47:c2:25
# 🔸 10:68:38:8d:70:a1
# 🔸 b4:8c:9d:14:34:5d
# 🔸 30:86:2d:60:81:30
# 🔸 68:6d:bc:f1:cf:b5
# 🔸 58:1c:f8:1c:21:90
# 🔸 8e:49:17:34:76:c0
# 🔸 ec:8a:48:d6:d8:ab
# 🔸 e8:65:38:22:33:75

# ------------------------------
