import json
from collections import defaultdict, Counter

LOG_FILE = 'sniffer_log.json'

def load_logs(file_path):
    with open(file_path, 'r') as f:
        return [json.loads(line.strip()) for line in f if line.strip()]

def summarize_traffic(logs):
    total = len(logs)
    protocols = Counter(log.get('protocol', 'Unknown') for log in logs)
    ips = Counter(log.get('src_ip', 'Unknown') for log in logs if 'src_ip' in log)

    print(f"\n📦 Total Packets Captured: {total}")
    print("\n📡 Protocol Usage:")
    for proto, count in protocols.items():
        print(f"  - {proto}: {count} packets")

    print("\n🌐 Top 5 Source IPs:")
    for ip, count in ips.most_common(5):
        print(f"  - {ip}: {count} packets")

def analyze_threats(logs):
    threat_logs = [log for log in logs if log.get('threats') and len(log['threats']) > 0]
    threat_counts = Counter(threat for log in threat_logs for threat in log.get('threats', []))
    ip_threats = Counter(log.get('src_ip', 'Unknown') for log in threat_logs)

    print(f"\n🛡️ Threat Summary (Detected {len(threat_logs)} threats):")
    for threat, count in threat_counts.items():
        print(f"  - {threat}: {count} packets")

    print("\n🚨 Top 5 Suspicious IPs:")
    for ip, count in ip_threats.most_common(5):
        print(f"  - {ip}: {count} threats")

def group_by_threat_type(logs):
    grouped = defaultdict(list)
    for log in logs:
        threats = log.get('threats', [])
        if not threats:
            grouped['normal'].append(log)
        else:
            for threat in threats:
                grouped[threat].append(log)
    return grouped

def export_threat_groups(grouped):
    for threat, entries in grouped.items():
        filename = f"threat_{threat.replace(' ', '_').lower()}.json"
        with open(filename, 'w') as f:
            for entry in entries:
                f.write(json.dumps(entry) + "\n")
        print(f"📝 Saved {len(entries)} entries to {filename}")

def main():
    try:
        logs = load_logs(LOG_FILE)
        print("📁 Logs loaded successfully.")

        summarize_traffic(logs)
        analyze_threats(logs)

        grouped_logs = group_by_threat_type(logs)
        export_threat_groups(grouped_logs)

    except FileNotFoundError:
        print(f"[x] Log file '{LOG_FILE}' not found.")
    except Exception as e:
        print(f"[x] Error: {e}")

if __name__ == "__main__":
    print("🔍 Running Threat Log Parser...")
    main()


# -----------------------------------------------------------------------------

# (sniffer) PS E:\4th Semester\Smart Sniffer> python parser/protocol_parser.py
# 🔍 Running Threat Log Parser...
# 📁 Logs loaded successfully.

# 📦 Total Packets Captured: 11388

# 📡 Protocol Usage:
#   - UDP: 5208 packets
#   - DNS: 69 packets
#   - ARP: 1759 packets
#   - TCP: 355 packets
#   - Unknown: 8 packets
#   - Raw: 2613 packets
#   - Padding: 1352 packets
#   - NBNS query request: 11 packets
#   - ICMPv6 Neighbor Discovery Option - Source Link-Layer Address: 6 packets
#   - MLD - Multicast Listener Report: 7 packets

# 🌐 Top 5 Source IPs:
#   - 180.149.59.40: 3159 packets
#   - 180.149.59.12: 1932 packets
#   - 172.18.32.234: 1293 packets
#   - None: 1156 packets
#   - 180.149.59.42: 1031 packets

# 🛡️ Threat Summary (Detected 9 threats):
#   - Possible SYN scan: 9 packets
#   - Suspicious port scan to port 443: 6 packets

# 🚨 Top 5 Suspicious IPs:
#   - 172.18.32.234: 7 threats
#   - 172.18.35.24: 2 threats
# 📝 Saved 11379 entries to threat_normal.json
# 📝 Saved 9 entries to threat_possible_syn_scan.json
# 📝 Saved 6 entries to threat_suspicious_port_scan_to_port_443.json

# ------------------------------------------------------------------------------