import json
import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import LabelEncoder, StandardScaler
import os

LOG_PATH = "E:\\4th Semester\\Smart Sniffer\\sniffer_log.json"
OUTPUT_PATH = "anomaly_logs.json"

def load_logs():
    with open(LOG_PATH, "r") as file:
        logs = [json.loads(line.strip()) for line in file if line.strip()]
    return logs

def extract_features(logs):
    data = []
    for log in logs:
        try:
            src_ip = log.get("src_ip", "0.0.0.0")
            dst_ip = log.get("dst_ip", "0.0.0.0")
            sport = log["details"].get("sport", 0) if isinstance(log["details"], dict) else 0
            dport = log["details"].get("dport", 0) if isinstance(log["details"], dict) else 0
            proto = log.get("protocol", "UNKNOWN")
            threat_score = len(log.get("threats", []))

            data.append({
                "src_ip": src_ip,
                "dst_ip": dst_ip,
                "sport": sport,
                "dport": dport,
                "protocol": proto,
                "threat_score": threat_score,
            })
        except Exception as e:
            print(f"[!] Skipping malformed log: {e}")
    return pd.DataFrame(data)

def preprocess(df):
    # IP encoding: Convert to numeric values
    for col in ["src_ip", "dst_ip"]:
        df[col] = df[col].apply(lambda ip: int("".join(f"{int(octet):03}" for octet in ip.split("."))) if ip else 0)

    # Protocol encoding
    proto_encoder = LabelEncoder()
    df["protocol"] = proto_encoder.fit_transform(df["protocol"])

    # Normalize
    scaler = StandardScaler()
    scaled_data = scaler.fit_transform(df)

    return scaled_data

def detect_anomalies(features, logs):
    model = IsolationForest(n_estimators=100, contamination=0.05, random_state=42)
    preds = model.fit_predict(features)

    anomalies = []
    for i, pred in enumerate(preds):
        if pred == -1:
            anomalies.append(logs[i])
    
    return anomalies

def save_anomalies(anomalies):
    with open(OUTPUT_PATH, "w") as f:
        for entry in anomalies:
            f.write(json.dumps(entry) + "\n")

def main():
    print("🤖 ML Anomaly Detection Started...")
    logs = load_logs()
    print(f"📦 Loaded {len(logs)} logs")

    df = extract_features(logs)
    features = preprocess(df)

    anomalies = detect_anomalies(features, logs)
    save_anomalies(anomalies)

    print(f"🚨 Detected {len(anomalies)} anomalous flows")
    print(f"📁 Anomalies saved to {OUTPUT_PATH}")

if __name__ == "__main__":
    main()
