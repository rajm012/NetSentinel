# fix_anomaly_json.py
input_path = "E:\\4th Semester\\Smart Sniffer\\ml_model\\anomaly_logs.json"
output_path = "E:\\4th Semester\\Smart Sniffer\\ml_model\\anomaly_logs_fixed.json"

with open(input_path, 'r') as infile:
    lines = infile.readlines()

# Convert to list of dicts
json_list = [eval(line.strip()) for line in lines if line.strip()]

import json
with open(output_path, 'w') as outfile:
    json.dump(json_list, outfile, indent=2)

print(f"✅ Fixed JSON saved to {output_path}")
